# -*- coding: utf8 -*-
# ### for Python 2.7 ###

import os
import sys
import codecs
import platform

print('Python version: ' + platform.python_version() )

output_to_file_in_utf8=''.join( ( os.path.splitext( os.path.realpath( sys.argv[0] ) )[0], '.cp1251.txt' ) )
str='ЙцуКенг, должен быть виден сейчас как строка в кодировке cp1251-8. В исходном .py-скрипте записан в кодировке utf8.' 
#print('Trying to write str=', str.decode('cp1251') )
with codecs.open( output_to_file_in_utf8, 'w', encoding='cp1251') as f:
    f.writelines( str.decode('utf-8') )
