-- Must be performed at the final stage of test preparing.
-- No output should be issued during this script work.
set bail on;
alter trigger trg_connect active;
set term ^;
execute block as
begin
    if (
        exists(select * from rdb$triggers where rdb$trigger_name = upper('TRG_DISCONNECT') )
        and exists(select * from rdb$relations where rdb$relation_name = upper('PERF_EDS') )
        ) then
    begin
        execute statement 'alter trigger trg_disconnect active';
    end
end
^
set term ;^
commit;
set list on;
set count on;
select g.rdb$trigger_name as "Trigger name", iif(g.rdb$trigger_inactive=1, '### INACTIVE ###', 'OK, active') as "Status"
from rdb$triggers g
where
    g.rdb$trigger_type in (
         8195 --  'on transaction commit'
        ,8196 -- 'on transaction rollback'
        ,8194 -- 'on transaction start'
        ,8193 -- 'on disconnect'
        ,8192 -- 'on connect'
    ) and
    g.rdb$system_flag is distinct from 1 ;
