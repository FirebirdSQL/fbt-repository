create or alter procedure pr_filltable_53 as begin end;
recreate table table_53 (
    id1 int,
    id2 int
);

set term ^;
create or alter procedure pr_filltable_53
as
    declare fillid int;
    declare fillid1 int;
begin
    fillid = 1;
    while (fillid <= 50) do
    begin
        fillid1 = (fillid / 10) * 10;
        insert into table_53(id1, id2)
        values(:fillid1, :fillid - :fillid1);
        fillid = fillid + 1;
    end
    insert into table_53 (id1, id2) values (0, null);
    insert into table_53 (id1, id2) values (null, 0);
    insert into table_53 (id1, id2) values (null, null);
end
^
set term ;^
commit;

execute procedure pr_filltable_53;
commit;

create asc index i_table_53_id1_asc on table_53 (id1);
create desc index i_table_53_id1_desc on table_53 (id1);
create asc index i_table_53_id2_asc on table_53 (id2);
create desc index i_table_53_id2_desc on table_53 (id2);
create asc index i_table_53_id1_id2_asc on table_53 (id1, id2);
create desc index i_table_53_id1_id2_desc on table_53 (id1, id2);
create asc index i_table_53_id2_id1_asc on table_53 (id2, id1);
create desc index i_table_53_id2_id1_desc on table_53 (id2, id1);
commit;

set planonly;

select t53.id2, t53.id1
from table_53 t53
where t53.id1 = 30 and t53.id2 >= 5
order by t53.id2 asc, t53.id1 asc;
